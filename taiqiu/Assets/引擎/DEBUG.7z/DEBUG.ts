// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

const { ccclass, property } = cc._decorator;

let INS: NewClass;

@ccclass
export default class NewClass extends cc.Component {

    @property(cc.Prefab)
    line: cc.Prefab = null;

    @property(cc.Prefab)
    sphere: cc.Prefab = null;

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}

    start () {
        INS = this;
    }

    // update (dt) {}
}

CANNON.Body['DrawLine'] = function (a: CANNON.Vec3, b: CANNON.Vec3) {
    var s = cc.instantiate(INS.line);
    s.setPosition(a.x, a.y, a.z);
    var c = new cc.Color(Math.random() * 255, Math.random() * 255, Math.random() * 255, 255);
    s.getComponentInChildren(cc.MeshRenderer).getMaterial(0).setProperty('diffuseColor', c);
    INS.node.addChild(s);
    var s1 = cc.instantiate(INS.line);
    s1.setPosition(b.x, b.y, b.z);
    s1.getComponentInChildren(cc.MeshRenderer).getMaterial(0).setProperty('diffuseColor', c);
    INS.node.addChild(s1);
}

CANNON.Body['DrawSphere'] = function (a: CANNON.Vec3, b: number) {
    var s = cc.instantiate(INS.sphere);
    s.setPosition(a.x, a.y, a.z);
    s.getComponent(cc.MeshRenderer).getMaterial(0).setProperty('diffuseColor', new cc.Color(Math.random() * 255, Math.random() * 255, Math.random() * 255, 100));
    INS.node.addChild(s);
}
