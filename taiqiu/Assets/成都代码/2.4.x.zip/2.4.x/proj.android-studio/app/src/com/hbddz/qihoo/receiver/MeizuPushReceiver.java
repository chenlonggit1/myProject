package com.hbddz.qihoo.receiver;

public class MeizuPushReceiver extends org.android.agoo.mezu.MeizuPushReceiver {

}
